Luma 0.2.0-experimental para Minecraft Java 26.2 / Fabric.
Abra COMECE-AQUI.txt. Copie apenas os dois JARs de mods para a pasta mods do jogo.
IA de texto original incluída, experimental e desligada por padrão.
Os testes ainda produziram texto sem sentido; não equivale a um modelo grande.
Nenhum Ollama, modelo pronto, chave de API ou serviço pago é necessário.
Voz e microfone continuam usando recursos do navegador/sistema.
Os relatórios e dados acompanham o pacote para consulta. Comandos de desenvolvimento
do laboratório exigem o repositório completo: https://github.com/lucasmac412/Mods
