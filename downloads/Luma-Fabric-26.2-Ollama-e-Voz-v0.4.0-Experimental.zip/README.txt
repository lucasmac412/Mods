Luma 0.4.0-experimental para Minecraft Java 26.2 / Fabric.
Abra COMECE-AQUI.txt. Copie os três JARs de mods para a pasta mods do jogo
e mescle config/luma-voice na pasta config do mesmo perfil do Minecraft.
Instale o Ollama e baixe qwen2.5:3b para a conversa: instruções no guia.
O modelo de conversa do Ollama não está neste ZIP. /luma ia ollama ativa a integração.
O modelo original pequeno ainda acompanha a Luma: /luma ia propria.
O complemento Luma Voz usa Vosk com modelo de terceiros para reconhecer português
localmente. Segure V para gravar e solte para enviar. A voz de saída depende
do sintetizador do sistema e de uma voz adequada instalada. Veja os limites no guia.
Ollama e os modelos de terceiros têm suas próprias licenças. Consulte third-party.
Os relatórios e dados acompanham o pacote para consulta. Comandos de desenvolvimento
do laboratório exigem o repositório completo: https://github.com/lucasmac412/Mods
